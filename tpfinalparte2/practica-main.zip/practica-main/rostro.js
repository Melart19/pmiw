class Rostro {
  constructor(princesa) {
    this.princesa = princesa;
    this.maqSeleccionado = 0;
    this.peloSeleccionado = 0;
  }

  mostrarMaquillaje() {
    this.princesa.mostrar();

    image(maqicono1Img, 40, 400, 70, 50);
    image(maqicono2Img, 140, 400, 70, 50);
    image(maqicono3Img, 240, 400, 70, 50);

    if (this.maqSeleccionado == 1) image(maq1Img, this.princesa.x, this.princesa.y);
    if (this.maqSeleccionado == 2) image(maq2Img, this.princesa.x, this.princesa.y);
    if (this.maqSeleccionado == 3) image(maq3Img, this.princesa.x, this.princesa.y);
  }

  mostrarPeinado() {
    this.princesa.mostrar();

    if (this.maqSeleccionado == 1) image(maq1Img, this.princesa.x, this.princesa.y);
    if (this.maqSeleccionado == 2) image(maq2Img, this.princesa.x, this.princesa.y);
    if (this.maqSeleccionado == 3) image(maq3Img, this.princesa.x, this.princesa.y);

    image(peCoImg, 40, 400, 70, 50);
    image(peMaImg, 145, 400, 60, 50);
    image(peRuImg, 240, 400, 70, 50);

    if (this.peloSeleccionado == 1) image(coloradaImg, this.princesa.x, this.princesa.y);
    if (this.peloSeleccionado == 2) image(marronImg, this.princesa.x, this.princesa.y);
    if (this.peloSeleccionado == 3) image(rubioImg, this.princesa.x, this.princesa.y);
  }

  detectarClickMaquillaje() {
    if (mouseX > 40 && mouseX < 110 && mouseY > 400 && mouseY < 450) return 1;
    if (mouseX > 140 && mouseX < 210 && mouseY > 400 && mouseY < 450) return 2;
    if (mouseX > 240 && mouseX < 310 && mouseY > 400 && mouseY < 450) return 3;
    return 0;
  }

  detectarClickPeinado() {
    if (mouseX > 40 && mouseX < 110 && mouseY > 400 && mouseY < 450) return 1;
    if (mouseX > 145 && mouseX < 205 && mouseY > 400 && mouseY < 450) return 2;
    if (mouseX > 240 && mouseX < 310 && mouseY < 450) return 3;
    return 0;
  }

  mostrarSeleccion() {
    // Maquillaje
    if (this.maqSeleccionado == 1) image(maq1Img, this.princesa.x, this.princesa.y);
    if (this.maqSeleccionado == 2) image(maq2Img, this.princesa.x, this.princesa.y);
    if (this.maqSeleccionado == 3) image(maq3Img, this.princesa.x, this.princesa.y);

    // Pelo
    if (this.peloSeleccionado == 1) image(coloradaImg, this.princesa.x, this.princesa.y);
    if (this.peloSeleccionado == 2) image(marronImg, this.princesa.x, this.princesa.y);
    if (this.peloSeleccionado == 3) image(rubioImg, this.princesa.x, this.princesa.y);
  }
}

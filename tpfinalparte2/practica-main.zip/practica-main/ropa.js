class Ropa {
  constructor(x, y) {
    this.x = x;
    this.y = y;

    this.vestidoSeleccionado = 0;

    this.vestidos = [vestido1, vestido2, vestido3];

    this.iconos = [
      { x: 70, y: 400, w: 60, h: 80 },
      { x: 170, y: 400, w: 60, h: 80 },
      { x: 270, y: 400, w: 60, h: 80 },
    ];
  }

  mostrar() {
    if (this.vestidoSeleccionado > 0) {
      let img = this.vestidos[this.vestidoSeleccionado - 1];
      image(img, this.x, this.y);
    }
  }

  mostrarOpciones() {
    for (let i = 0; i < this.vestidos.length; i++) {
      let ico = this.iconos[i];
      image(this.vestidos[i], ico.x, ico.y, ico.w, ico.h);

      if (this.vestidoSeleccionado == i + 1) {
        noFill();
        stroke(255, 100, 150);
        strokeWeight(3);
        rect(ico.x - 5, ico.y - 5, ico.w + 10, ico.h + 10, 10);
      }
    }
  }

  seleccionar() {
    for (let i = 0; i < this.iconos.length; i++) {
      let ico = this.iconos[i];

      if (
        mouseX > ico.x &&
        mouseX < ico.x + ico.w &&
        mouseY > ico.y &&
        mouseY < ico.y + ico.h
      ) {
        this.vestidoSeleccionado = i + 1;
      }
    }
  }
}
